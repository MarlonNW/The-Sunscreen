﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {




        string dados;
        string portaselecionada;

        public Form1()
        {
            InitializeComponent();
            string[] portas = System.IO.Ports.SerialPort.GetPortNames();//Aqui original SerialPort.GetPortNames();
            foreach (string mostrar in portas)
            {
                comboBox1.Items.Add(mostrar);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            serialPort1.Close();
            serialPort1.Dispose();
            Close();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            serialPort1.Close();
            serialPort1.Dispose();
            portaselecionada = comboBox1.Text;
            serialPort1.PortName = portaselecionada;
            serialPort1.Open();
            CheckForIllegalCrossThreadCalls = false;
            if (serialPort1 . IsOpen == true)
            {
label3 . Text = "portaselecionada encontrada";
            }
            else
            {
                return;
            }
           
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            dados = serialPort1.ReadLine();
            double numero = Convert.ToDouble(dados);
            label4.Text = numero.ToString();

            if (numero == 0)
            {


                pictureBox1.Visible = true;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                pictureBox4.Visible = false;
                pictureBox5.Visible = false;
            }

            if (numero >= 250 && numero < 500)
            {
                pictureBox1.Visible = false;
                pictureBox2.Visible = true;
                pictureBox3.Visible = false;
                pictureBox4.Visible = false;
                pictureBox5.Visible = false;
            }

            if (numero >= 500 && numero < 750)
            {
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = true;
                pictureBox4.Visible = false;
                pictureBox5.Visible = false;
            }

            if (numero >= 750 && numero < 1020)
            {
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                pictureBox4.Visible = true;
                pictureBox5.Visible = false;
            }

            if (numero >= 1020)
            {
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                pictureBox4.Visible = false;
                pictureBox5.Visible = true;
            }



        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
          

        }

        private void button2_Click(object sender, EventArgs e)
        {
           
        }

        private void timer1_Tick(object sender, EventArgs e)
        {



         
               
       



            
        }
    }
}
